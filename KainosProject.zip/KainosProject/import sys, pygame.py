import sys, pygame
import random
import os

os.environ['SDL_AUDIODRIVER'] = 'dsp'

pygame.init()


WINDOW_WIDTH = 600
WINDOW_HEIGHT = 400
window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Colour match")
clock = pygame.time.Clock()
FPS = 60

#font
splash_font = pygame.font.SysFont(None, 48)
letter_font = pygame.font.SysFont(None, 28)
highscore_font = pygame.font.SysFont(None, 28)
submit_button_font = pygame.font.SysFont(None, 32)
grade_font = pygame.font.SysFont(None, 20)
score_font = pygame.font.SysFont(None, 24)
controls_font = pygame.font.SysFont(None, 42)
difficulty_font = pygame.font.SysFont(None, 42)
difficulty_font_selected = pygame.font.SysFont(None, 42, True)
smaller_font = pygame.font.SysFont(None, 12, True)

#splashScreen
count = 255 #count for fading JHEG STUDIOS
count2 = 255 #count for fading Presents
count3 = 0 
count4 = 0 #count for fading the black into white
count5 = 0 
game_name = False
game_menu = False
countForColour = 0 #added so that the colour of the game name doesnt change evry frame

prevr =0
prevg =0
prevb =0

#timer
count_for_mem = 720
memory = False
user_input = False

#rand
random_red = 0
random_green = 0
random_blue = 0

#user input
user_red = 0
user_green = 0
user_blue = 0
selected_colour = "red" #set to red by default
submit_button = pygame.Rect(120, 230, 160, 30)

#result logic
result = 0.00
displayed_result = 0.00

#game logic
passing_percent = 80.00 #default value
difficulty = 1

#score logic
high_score = 0
running_score = 0

#Pre declared colours
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (238, 0, 0)
GREEN = (0, 176, 80)
BLUE = (0, 112, 192)


running = True
while running:
    for event in pygame.event.get():
        keys = pygame.key.get_pressed()
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_a: ##A KEY EVENTS
            if game_menu: #start round
                game_name = False
                count3 = 101
                window.fill(WHITE)
                memory = True
                timer = splash_font.render(str(count_for_mem / 60) , True, BLACK)
                window.blit(timer, (275, 300))
                
                random_red = random.randint(0, 255)
                random_green = random.randint(0, 255)
                random_blue = random.randint(0, 255)   
                difficulty = 1            
            elif user_input == True and displayed_result != 0.00: 
                if displayed_result >= passing_percent: #continue to the next round        
                    user_red =0
                    user_blue =0
                    user_green =0                           
                    running_score = running_score + 1
                    memory = True
                    user_input = False
                    random_red = random.randint(0, 255)
                    random_green = random.randint(0, 255)
                    random_blue = random.randint(0, 255)  
                    count_for_mem = 720
                    count5 = 0
                    selected_colour = "red"
                    displayed_result = 0
                    result = 0
                    if passing_percent < 100.00:
                        passing_percent = passing_percent + 1 # ramp up the difficulty
                    if difficulty < 2.00:
                        difficulty = difficulty + 0.1  # ramp up difficulty                                    
                elif displayed_result < passing_percent: #return to menu
                    user_input = False
                    game_name = True
                    game_menu = True
                    high_score = max(high_score, running_score)
                    count_for_mem = 720
                    count5 = 0
                    selected_colour = "red"
                    displayed_result = 0
                    result = 0   
                    count3 = 100       
                    passing_percent = 80.00
                    user_blue = 0
                    user_green = 0
                    user_red = 0                     
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r: #select red
            selected_colour = "red"
        if event.type == pygame.KEYDOWN and event.key == pygame.K_g: #select green
            selected_colour = "green"
        if event.type == pygame.KEYDOWN and event.key == pygame.K_b: #select blue
            selected_colour = "blue" 
             
           
        if event.type == pygame.KEYDOWN and event.key == pygame.K_UP: 
            if selected_colour == "red":
                if user_red < 255:
                    user_red = user_red + 1
            elif selected_colour == "green":
                if user_green < 255:
                     user_green = user_green + 1
            elif selected_colour == "blue":
                if user_blue < 255:
                     user_blue = user_blue + 1  
        if event.type == pygame.KEYDOWN and event.key == pygame.K_DOWN:
            if selected_colour == "red":
                if user_red > 0:
                    user_red = user_red - 1
            elif selected_colour == "green":
                if user_green > 0:
                    user_green = user_green - 1
            elif selected_colour == "blue":
                if user_blue > 0:
                    user_blue = user_blue - 1   
                    
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and user_input == True:
            if submit_button.collidepoint(event.pos):  
                difference =0
                if user_red > random_red:
                    difference = difference + (user_red - random_red) * difficulty  #after playtesting i found that players could input a general colour eg. rgb(125, 125, 125) and pass consisntently 
                else:                                                               #so i made the difference matter more and increased the difficulty as the player gained more score aswell to make ater rounds more challenging
                    difference = difference + (random_red - user_red) * difficulty
                if user_green > random_green:
                    difference = difference + (user_green - random_green) * difficulty
                else:
                    difference = difference + (random_green - user_green) * difficulty
                if user_blue > random_blue:
                    difference = difference + (user_blue - random_blue) * difficulty
                else:
                    difference = difference + (random_blue - user_blue) * difficulty
                     
                result = 765 - difference
                result = result / 765
                result = result * 100
                result = round(result, 2)
    if count3 == 100:
        if not count4 == 255:
            COLOR = (count4, count4, count4)
            window.fill(COLOR)
            count4 = count4 + 1
        else:
            game_menu = True
            window.fill(WHITE)
            #menu controls
            pressA = splash_font.render("Press A to start", True, (BLACK))
            window.blit(pressA, (175, 220))  
            Aaron = smaller_font.render("Aaron appreciation corner", True, (BLACK))
            window.blit(Aaron, (460, 0))  
            highscore = highscore_font.render("Highscore: " + str(high_score), True, (BLACK))
            window.blit(highscore, (20, 20)) 
            
    elif count > 0:
        #start
        window.fill(BLACK)
        studio_name = splash_font.render("JHEG STUDIOS", True, (count,count,count))
        window.blit(studio_name, (180, 180))  
        count = count -1
    else:
        if count2 > 0:
            #presents
            window.fill(BLACK)
            presents = splash_font.render("PRESENTS", True, (count2,count2,count2))
            window.blit(presents, (200, 180))  
            count2 = count2 -1
        elif not game_menu:
            game_name = True
            
    if game_name:
        #code for random colour for game name
        if not count3 == 100: 
            window.fill(BLACK)
        if countForColour == 10:
            r = random.randint(125, 255)
            g = random.randint(125, 255)
            b = random.randint(125, 225)  
            prevr = r
            prevg = g
            prevb = b
            game_name_text = splash_font.render("COLOUR MATCH", True, (r, g, b))
            window.blit(game_name_text, (160, 180)) 
            countForColour = 0
        else:
            game_name_text = splash_font.render("COLOUR MATCH", True, (prevr,prevg, prevb))
            window.blit(game_name_text, (160, 180)) 
            countForColour = countForColour + 1
            if not count3 == 100:
                count3 = count3 + 1
    if memory:
        #code for the memory part 
        game_menu = False
        window.fill(WHITE)
        pygame.draw.rect(window, (random_red, random_green, random_blue), (200, 120, 200, 200)) 
        pygame.draw.rect(window, (0, 0, 0), (200, 120, 200, 200), 1 )
        count_for_mem = count_for_mem -1
        instruct = splash_font.render("Memorise this colour", True, BLACK)
        window.blit(instruct, (140, 40)) 
        timer = splash_font.render(str(round(count_for_mem / 120)) , True, BLACK)
        window.blit(timer, (290, 340))
        if count_for_mem > 0:
            count_for_mem = count_for_mem -1  
        else:
            memory = False
            user_input = True
    if user_input:
        mouse_pos = pygame.mouse.get_pos()
        hovering = submit_button.collidepoint(mouse_pos)  
        pygame.key.set_repeat(100,10)
        window.fill(WHITE) 
        pygame.draw.rect(window, (242, 242, 242), (0, 0, 90, 400)) 
        pygame.draw.rect(window, (116, 116, 116), (90, 0, 10, 400))    #left border 
        pygame.draw.rect(window, (116, 116, 116), (300, 0, 10, 400))   #right border

        pygame.draw.rect(window, (user_red, user_green, user_blue), (135, 90, 125, 125)) # users colour

        button_color = (0, 242, 109) if hovering else (0, 176, 80) #submit button
        pygame.draw.rect(window, button_color, submit_button)
        submit_text = submit_button_font.render("SUBMIT" , True, WHITE)
        window.blit(submit_text, (154, 235)) 

        #page
        pygame.draw.rect(window, (254, 250, 248), (310, 0, 300, 400))

        pygame.draw.rect(window, (0, 0, 0), (310, 60, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 90, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 120, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 150, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 180, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 210, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 240, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 270, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 300, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 330, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 360, 400, 3))
        pygame.draw.rect(window, (0, 0, 0), (310, 390, 400, 3))


        pygame.draw.rect(window, (238, 0, 0), (355, 0, 5 , 400))

        yellow_paint_image = pygame.image.load("yellowSplodge.png")
        yellow_paint_image = pygame.transform.scale(yellow_paint_image, (60, 200))
        yellow_rect = yellow_paint_image.get_rect()
        yellow_rect.center = (590, 150)
        window.blit(yellow_paint_image, (yellow_rect))  

        blue_paint_image = pygame.image.load("blueSplash.png")
        blue_paint_image = pygame.transform.scale(blue_paint_image, (140, 140))
        blue_rect = blue_paint_image.get_rect()
        blue_rect.center = (400, 250)
        window.blit(blue_paint_image, (blue_rect))

        pygame.draw.circle(window, (50, 150, 240), (370, 300), (8))  
        pygame.draw.circle(window, (50, 150, 240), (345, 280), (6))
        pygame.draw.circle(window, (50, 150, 240), (390, 330), (5))  
        pygame.draw.circle(window, (50, 150, 240), (440, 330), (10))  

        pygame.draw.circle(window, (245, 23, 0), (530, 300), (10)) 
        pygame.draw.circle(window, (245, 23, 0), (545, 280), (6)) 
        pygame.draw.circle(window, (245, 23, 0), (470, 350), (7)) 

        pygame.draw.circle(window, (245, 245, 0), (550, 220), (7))
        pygame.draw.circle(window, (245, 245, 0), (550, 120), (9))
        pygame.draw.circle(window, (245, 245, 0), (555, 140), (4))        

        pygame.draw.circle(window, (125, 190, 0), (570, 60), (9))
        pygame.draw.circle(window, (125, 190, 0), (580, 70), (4))

        red_paint_image = pygame.image.load("redDampen.png")
        red_paint_image = pygame.transform.scale(red_paint_image, (140, 115))
        red_rect = red_paint_image.get_rect()
        red_rect.center = (540, 320)
        window.blit(red_paint_image, (red_rect))  

        green_paint_image = pygame.image.load("greenGoo.png")
        green_paint_image = pygame.transform.scale(green_paint_image, (200, 130))
        green_rect = green_paint_image.get_rect()
        green_rect.center = (450, 100)
        window.blit(green_paint_image, (green_rect)) 

        pygame.draw.rect(window, (255,255, 255), (370, 80, 200, 40))
        pygame.draw.rect(window, (0,0, 0), (370, 80, 200, 40), 1)
        grade_text = grade_font.render("Grade needed to pass: " + str(passing_percent) , True, (235, 0, 0))
        window.blit(grade_text, (385, 90)) 



        pygame.draw.rect(window, (255,255, 255), (390, 150, 160, 40))
        pygame.draw.rect(window, (0,0, 0), (390, 150, 160, 40), 1)
        grade_text = grade_font.render("Score: " + str(running_score) , True, (0, 0, 0))
        window.blit(grade_text, (400, 160)) 

        pygame.draw.rect(window, (255,255, 255), (390, 200, 160, 40))
        pygame.draw.rect(window, (0,0, 0), (390, 200, 160, 40), 1)   
        grade_text = grade_font.render("Accuracy: " + str(displayed_result) , True, (0, 0, 0))
        window.blit(grade_text, (400, 210))      
 
        if result >= passing_percent and result != 0.00 and count5 == 100:           
            pygame.draw.rect(window, (255,255, 255), (377, 260, 180, 40))
            pygame.draw.rect(window, (0,0, 0), (377, 260, 180, 40), 1)
            message_for_user = grade_font.render("Congrats you have passed", True, (0, 0, 0))
            window.blit(message_for_user, (385, 270))
            continue_text = grade_font.render("Press A to continue", True, (0, 0, 0))
            window.blit(continue_text, (410, 310))            
        elif result != 0.00 and count5 == 100:
            pygame.draw.rect(window, (255,255, 255), (371, 260, 200, 40))
            pygame.draw.rect(window, (0 ,0, 0), (371, 260, 200, 40), 1)         
            message_for_user = grade_font.render("Unfortunately you have failed", True, (0, 0, 0))
            result_text = grade_font.render("Your final score is: " + str(running_score) , True, (0, 0, 0))
            window.blit(result_text, (390, 280))         
            window.blit(message_for_user, (377, 265))              
            continue_text = grade_font.render("Press A to continue", True, (0, 0, 0))
            window.blit(continue_text, (410, 310)) 
            pygame.key.set_repeat(0)

        pygame.draw.circle(window, (116, 116, 116), (330, 80), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 130), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 180), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 230), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 280), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 330), ( 15))
        pygame.draw.circle(window, (116, 116, 116), (330, 380), ( 15))


        red_bar = pygame.draw.rect(window, (RED), (10, 85, 10, (user_red + 1)))
        green_bar = pygame.draw.rect(window, (GREEN), (35, 85, 10, (user_green + 1)))
        blue_bar = pygame.draw.rect(window, (0, 112, 192), (60, 85, 10, (user_blue + 1)))

        if not result == 0.0:
            if not count5 == 100:
                division = result / 100
                displayed_result = displayed_result + division
                displayed_result = round(displayed_result, 3)
                count5 = count5 + 1

             
        if selected_colour == "red":
            R = letter_font.render("R" , True, BLACK, (220, 220, 255))
        else:
            R = letter_font.render("R" , True, BLACK, )
        window.blit(R, (10, 50)) 
        if selected_colour == "green":
            G = letter_font.render("G" , True, BLACK, (220, 220, 255))
        else:
            G = letter_font.render("G" , True, BLACK,)
        window.blit(G, (35, 50)) 
        if selected_colour == "blue":
            B = letter_font.render("B" , True, BLACK, (220, 220, 255))
        else:
            B = letter_font.render("B" , True, BLACK, )
        window.blit(B, (60, 50)) 
        pygame.draw.rect(window, (58, 58, 58), (0, 0, 600, 40))  
        pygame.draw.rect(window, (58, 58, 58), (0, 360, 600, 40))  
    pygame.display.update()    
    clock.tick(FPS)
    
    
pygame.quit()